#!/system/bin/sh
echo "active:"
grep -m1 '33, 04' /vendor/etc/libnfc-nxp.conf
grep -E '^DEFAULT_.*ROUTE=0x' /vendor/etc/libnfc-nxp.conf

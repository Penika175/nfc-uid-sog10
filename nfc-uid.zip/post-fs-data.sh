#!/system/bin/sh
BASE=/data/adb/nfc-uid
[ -f "$BASE/active.conf" ] || exit 0
mount --bind "$BASE/active.conf" /vendor/etc/libnfc-nxp.conf 2>/dev/null
